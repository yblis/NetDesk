// Content script to inject RustDesk buttons into NetBird dashboard
// This script runs on the NetBird dashboard page

let osType = 'unknown';
let buttonStyle = 'default';

console.log('NetDesk content script loaded');

// Get the OS type from the background script
chrome.runtime.sendMessage({action: "getOS"}, (response) => {
  if (response && response.os) {
    osType = response.os;
    console.log("Detected OS:", osType);
  } else {
    console.log("Failed to detect OS");
  }
});

// Get extension settings
chrome.storage.sync.get(['buttonStyle'], (result) => {
  if (result.buttonStyle) {
    buttonStyle = result.buttonStyle;
  }
  console.log("Button style:", buttonStyle);
});

// Function to create a RustDesk button
function createRustDeskButton(peerId, peerName) {
  const button = document.createElement('button');
  button.className = 'rustdesk-connect-btn';
  
  // Apply selected style
  if (buttonStyle === 'icon') {
    button.classList.add('icon-style');
    button.innerHTML = 'R';
  } else {
    button.innerHTML = 'RustDesk';
  }
  
  button.title = `Connect to ${peerName} via RustDesk`;
  button.dataset.peerId = peerId;
  button.dataset.peerName = peerName;
  
  button.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    
    // Send message to background script to launch RustDesk
    chrome.runtime.sendMessage({
      action: "launchRustDesk",
      peerId: peerId,
      os: osType
    }, (response) => {
      if (response && !response.success) {
        console.error("Failed to launch RustDesk:", response.error);
        // Show error to user
        alert(`Failed to launch RustDesk: ${response.error}`);
      }
    });
  });
  
  return button;
}

// Function to inject buttons into the peer table
function injectRustDeskButtons() {
  console.log('Attempting to inject RustDesk buttons');
  
  // Try to find the peer table rows in NetBird dashboard
  const peerRows = document.querySelectorAll('tbody tr[data-row-id]');
  console.log('Found peer rows:', peerRows.length);
  
  if (peerRows.length === 0) {
    // Try alternative selectors for the actual NetBird structure
    const altRows = document.querySelectorAll('tr.group\\/table-row[data-row-id]');
    console.log('Alternative selector found rows:', altRows.length);
    
    if (altRows.length > 0) {
      altRows.forEach((row, index) => {
        processPeerRow(row, index);
      });
      return;
    }
  }
  
  peerRows.forEach((row, index) => {
    processPeerRow(row, index);
  });
}

// Helper function to process a peer row
function processPeerRow(row, index) {
  console.log(`Processing row ${index}:`, row);
  
  // Skip rows that already have a RustDesk button
  if (row.querySelector('.rustdesk-connect-btn')) {
    console.log(`Row ${index} already has RustDesk button`);
    return;
  }
  
  // Find the peer name cell using the data-testid attribute
  const peerNameCell = row.querySelector('[data-testid="peer-name-cell"]');
  console.log(`Row ${index} peer name cell:`, peerNameCell);
  
  if (peerNameCell) {
    // Extract peer name from the nested structure
    // Look for the truncate div that contains the actual peer name
    const peerNameElement = peerNameCell.querySelector('.truncate');
    console.log(`Row ${index} peer name element:`, peerNameElement);
    
    if (peerNameElement) {
      const peerName = peerNameElement.textContent.trim();
      console.log(`Row ${index} peer name:`, peerName);
      
      // Create a unique ID based on the peer name
      const peerId = peerName.replace(/\s+/g, '-').toLowerCase();
      console.log(`Row ${index} peer ID:`, peerId);
      
      if (peerName && peerId) {
        const button = createRustDeskButton(peerId, peerName);
        
        // Find a suitable place to insert the button
        // We'll add it to the peer name cell
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'rustdesk-button-container';
        buttonContainer.style.cssText = 'display: inline-flex; align-items: center; margin-left: 10px;';
        buttonContainer.appendChild(button);
        
        // Insert the button next to the peer name
        peerNameCell.appendChild(buttonContainer);
        console.log(`Successfully added RustDesk button for ${peerName}`);
      }
    }
  } else {
    console.log(`Row ${index} does not have peer name cell with data-testid="peer-name-cell"`);
    
    // Try to find the peer name in the actual NetBird structure
    const nameDiv = row.querySelector('div.font-medium .truncate');
    if (nameDiv) {
      const peerName = nameDiv.textContent.trim();
      console.log(`Row ${index} found peer name in alternative structure:`, peerName);
      
      // Create a unique ID based on the peer name
      const peerId = peerName.replace(/\s+/g, '-').toLowerCase();
      console.log(`Row ${index} peer ID:`, peerId);
      
      if (peerName && peerId) {
        const button = createRustDeskButton(peerId, peerName);
        
        // Create a container for the button
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'rustdesk-button-container';
        buttonContainer.style.cssText = 'display: inline-flex; align-items: center; margin-left: 10px;';
        buttonContainer.appendChild(button);
        
        // Insert the button next to the peer name
        nameDiv.parentElement.parentElement.appendChild(buttonContainer);
        console.log(`Successfully added RustDesk button for ${peerName}`);
      }
    }
  }
}

// Function to observe changes in the DOM and inject buttons when needed
function observeDashboard() {
  // Create a MutationObserver to watch for changes in the dashboard
  const observer = new MutationObserver((mutations) => {
    let shouldInject = false;
    
    mutations.forEach((mutation) => {
      // Check if any new nodes were added
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldInject = true;
      }
    });
    
    if (shouldInject) {
      // Small delay to ensure DOM is fully updated
      setTimeout(injectRustDeskButtons, 100);
    }
  });
  
  // Start observing the document body for changes
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Initial injection
  setTimeout(injectRustDeskButtons, 1000);
}

// Wait for the page to load before injecting buttons
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', observeDashboard);
} else {
  observeDashboard();
}

// Also run periodically in case the dashboard updates in a way that bypasses MutationObserver
setInterval(injectRustDeskButtons, 5000);
