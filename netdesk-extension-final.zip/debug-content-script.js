// Debug script to help troubleshoot NetDesk extension issues
// This script can be run in the browser console to test selectors

console.log('=== NetDesk Debug Script ===');

// Check if we're on a NetBird page
console.log('Current page:', window.location.href);
console.log('Page includes "netbird":', window.location.href.includes('netbird'));

// Try to find peer rows
console.log('\n--- Looking for peer rows ---');
const peerRows = document.querySelectorAll('tbody tr[data-row-id]');
console.log('Found peer rows with tbody selector:', peerRows.length);

const altRows = document.querySelectorAll('tr[data-row-id]');
console.log('Found peer rows with general selector:', altRows.length);

const groupRows = document.querySelectorAll('tr.group\\/table-row[data-row-id]');
console.log('Found peer rows with group selector:', groupRows.length);

// Try to find peer name cells
console.log('\n--- Looking for peer name cells ---');
const peerNameCells = document.querySelectorAll('[data-testid="peer-name-cell"]');
console.log('Found peer name cells:', peerNameCells.length);

// Examine the structure of the first few rows
if (peerRows.length > 0) {
  console.log('\n--- Examining first peer row ---');
  const firstRow = peerRows[0];
  console.log('First row:', firstRow);
  console.log('First row attributes:', firstRow.attributes);
  
  // Look for the peer name cell in this row
  const nameCell = firstRow.querySelector('[data-testid="peer-name-cell"]');
  console.log('Name cell in first row:', nameCell);
  
  if (nameCell) {
    const truncateElement = nameCell.querySelector('.truncate');
    console.log('Truncate element:', truncateElement);
    if (truncateElement) {
      console.log('Peer name:', truncateElement.textContent);
    }
  }
} else if (altRows.length > 0) {
  console.log('\n--- Examining first alternative row ---');
  const firstRow = altRows[0];
  console.log('First row:', firstRow);
  
  // Look for the peer name cell in this row
  const nameCell = firstRow.querySelector('[data-testid="peer-name-cell"]');
  console.log('Name cell in first row:', nameCell);
  
  if (nameCell) {
    const truncateElement = nameCell.querySelector('.truncate');
    console.log('Truncate element:', truncateElement);
    if (truncateElement) {
      console.log('Peer name:', truncateElement.textContent);
    }
  }
}

// Try to find the actual structure from the example
console.log('\n--- Looking for specific NetBird structure ---');
const fontMediumElements = document.querySelectorAll('.font-medium .truncate');
console.log('Found font-medium truncate elements:', fontMediumElements.length);

if (fontMediumElements.length > 0) {
  fontMediumElements.forEach((el, index) => {
    console.log(`Element ${index}:`, el.textContent.trim());
  });
}

console.log('\n=== Debug Script Complete ===');
