// Content script to inject RustDesk buttons into NetBird dashboard
// This script runs on the NetBird dashboard page

let osType = 'unknown';
let buttonStyle = 'default';

// Get the OS type from the background script
chrome.runtime.sendMessage({action: "getOS"}, (response) => {
  if (response && response.os) {
    osType = response.os;
    console.log("Detected OS:", osType);
  }
});

// Get extension settings
chrome.storage.sync.get(['buttonStyle'], (result) => {
  if (result.buttonStyle) {
    buttonStyle = result.buttonStyle;
  }
});

// Function to create a RustDesk button
function createRustDeskButton(peerId, peerName) {
  const button = document.createElement('button');
  button.className = 'rustdesk-connect-btn';
  
  // Apply selected style
  if (buttonStyle === 'icon') {
    button.classList.add('icon-style');
    button.innerHTML = 'R';
  } else {
    button.innerHTML = 'RustDesk';
  }
  
  button.title = `Connect to ${peerName} via RustDesk`;
  button.dataset.peerId = peerId;
  button.dataset.peerName = peerName;
  
  button.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    
    // Send message to background script to launch RustDesk
    chrome.runtime.sendMessage({
      action: "launchRustDesk",
      peerId: peerId,
      os: osType
    }, (response) => {
      if (response && !response.success) {
        console.error("Failed to launch RustDesk:", response.error);
        // Show error to user
        alert(`Failed to launch RustDesk: ${response.error}`);
      }
    });
  });
  
  return button;
}

// Function to inject buttons into the peer table
function injectRustDeskButtons() {
  // Try to find the peer table
  // This selector may need to be adjusted based on the actual NetBird dashboard structure
  const peerRows = document.querySelectorAll('tbody tr');
  
  peerRows.forEach(row => {
    // Skip rows that already have a RustDesk button
    if (row.querySelector('.rustdesk-connect-btn')) return;
    
    // Try to extract peer information
    // This will need to be adjusted based on the actual structure
    const cells = row.querySelectorAll('td');
    if (cells.length >= 2) {
      // Assuming the first cell contains the peer name and the second contains IP
      // We'll use the peer name as the ID for RustDesk
      const peerNameElement = cells[0];
      const peerName = peerNameElement.textContent.trim();
      
      // Create a unique ID based on the peer name (this might need adjustment)
      const peerId = peerName.replace(/\s+/g, '-').toLowerCase();
      
      if (peerName && peerId) {
        const button = createRustDeskButton(peerId, peerName);
        
        // Insert the button in the first cell or create a new cell for it
        const buttonCell = document.createElement('td');
        buttonCell.appendChild(button);
        row.insertBefore(buttonCell, row.firstChild);
      }
    }
  });
}

// Function to observe changes in the DOM and inject buttons when needed
function observeDashboard() {
  // Create a MutationObserver to watch for changes in the dashboard
  const observer = new MutationObserver((mutations) => {
    let shouldInject = false;
    
    mutations.forEach((mutation) => {
      // Check if any new nodes were added
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldInject = true;
      }
    });
    
    if (shouldInject) {
      // Small delay to ensure DOM is fully updated
      setTimeout(injectRustDeskButtons, 100);
    }
  });
  
  // Start observing the document body for changes
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Initial injection
  setTimeout(injectRustDeskButtons, 1000);
}

// Wait for the page to load before injecting buttons
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', observeDashboard);
} else {
  observeDashboard();
}

// Also run periodically in case the dashboard updates in a way that bypasses MutationObserver
setInterval(injectRustDeskButtons, 5000);
