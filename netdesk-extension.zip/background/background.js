// Background script for NetDesk Chrome Extension
// Handles OS detection and communication with content script

// Detect the user's operating system
function detectOS() {
  const userAgent = navigator.userAgent;
  const platform = navigator.platform;
  
  if (userAgent.includes('Win')) return 'windows';
  if (userAgent.includes('Mac')) return 'mac';
  if (userAgent.includes('Linux') || userAgent.includes('X11')) return 'linux';
  if (/iPad|iPhone|iPod/.test(userAgent)) return 'ios';
  if (userAgent.includes('Android')) return 'android';
  
  return 'unknown';
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
 if (request.action === "getOS") {
    sendResponse({os: detectOS()});
  } else if (request.action === "launchRustDesk") {
    // Attempt to launch RustDesk with the provided ID
    const { peerId, os } = request;
    
    // Different launch methods based on OS
    let launchUrl;
    switch (os) {
      case 'windows':
        launchUrl = `rustdesk://connection/new/${peerId}`;
        break;
      case 'mac':
        launchUrl = `rustdesk://connection/new/${peerId}`;
        break;
      case 'linux':
        launchUrl = `rustdesk://connection/new/${peerId}`;
        break;
      default:
        launchUrl = `rustdesk://connection/new/${peerId}`;
    }
    
    // Try to launch the URL
    chrome.tabs.update(sender.tab.id, {url: launchUrl})
      .catch(error => {
        console.error("Failed to launch RustDesk:", error);
        sendResponse({success: false, error: error.message});
      });
      
    sendResponse({success: true, url: launchUrl});
  }
  
  // Return true to indicate we'll send a response asynchronously
  return true;
});
