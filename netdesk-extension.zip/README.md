# NetDesk - NetBird to RustDesk Connector

A Chrome extension that adds RustDesk connection buttons to the NetBird dashboard.

## Features

- Adds a "RustDesk" button next to each peer in the NetBird dashboard
- Automatically detects your operating system (Windows, macOS, Linux, iOS, Android)
- Launches the appropriate RustDesk client for your OS
- Supports custom NetBird dashboard URLs
- Configurable button styles (text or icon)

## Installation

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the extension directory
5. The extension icon should now appear in your Chrome toolbar

## Usage

1. Navigate to your NetBird dashboard (https://app.netbird.io or your custom URL)
2. The extension will automatically inject RustDesk buttons next to each peer
3. Click the "RustDesk" button to initiate a connection to that peer
4. The appropriate RustDesk client for your OS will launch

## Configuration

You can configure the extension by clicking the extension icon and selecting "Options":

- Set a custom NetBird dashboard URL
- Choose between text or icon-only button styles

## How It Works

- The extension uses content scripts to modify the NetBird dashboard page
- It detects peer information directly from the dashboard table
- OS detection is performed to launch the correct RustDesk client
- Peer IDs are assumed to be the same in both NetBird and RustDesk

## Requirements

- Chrome browser
- RustDesk client installed on your device
- Access to NetBird dashboard

## Limitations

- This extension assumes that peers have the same ID in both NetBird and RustDesk
- The button injection may need adjustment based on the actual NetBird dashboard structure
- Some security settings may prevent the extension from launching external applications

## Support

For issues or feature requests, please open an issue on this repository.
